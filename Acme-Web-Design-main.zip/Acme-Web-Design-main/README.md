# Acme-Web-Design
Welcome to Acme Web Design website
This is another incredible project from Brad Traversy. Thanks to him, we can practice how to build a responsive mobile-friendly HTML5 website from scratch.

As a big fan of Traversy Media, I can assure that this project is must-do for all beginners. This is an amazing tutorial to practice using semantic HTML tags and CSS.

Within this project we learned how to build a development strategy and to follow it step by step through branching.

Feel free to check out the workflow of this project 🚀💻
